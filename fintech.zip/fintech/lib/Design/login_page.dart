import 'package:fintech/Design/home_page.dart';
import 'package:flutter/material.dart';

/*
Add aadhar verification on the button in line number 61.
*/
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool _obsure = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Login',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: EdgeInsets.all(15),
          ),
          TextField(
            obscureText: _obsure,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              hintText: 'Account Number',
              labelText: 'Account Number',
              suffixIcon: IconButton(
                icon: Icon(_obsure ? Icons.visibility : Icons.visibility_off),
                onPressed: () {
                  setState(() {
                    _obsure = !_obsure;
                  });
                },
              ),
            ),
          ),
          TextField(
            decoration: InputDecoration(
              hintText: 'Aadhaar Number',
              labelText: 'Aadhaar Number',
            ),
          ),
          ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => HomePage()));
              },
              child: Text(
                'Verification', //<- Verification
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.w400),
              )),
        ],
      ),
    );
  }
}
