import 'dart:async';
import 'package:fintech/Design/login_signup.dart';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    // TODO: implement initState
    Timer(Duration(seconds: 7), () {
      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (_) => LoginSignup()), (route) => (true));
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Hero(
        tag: 'LOGO UNION BANK',
        child: Image.asset(
          'assets/union.jpeg',
          height: 100,
          width: 100,
        ),
      ),
    );
  }
}
