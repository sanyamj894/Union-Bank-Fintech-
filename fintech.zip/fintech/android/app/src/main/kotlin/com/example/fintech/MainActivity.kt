package com.example.fintech

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
